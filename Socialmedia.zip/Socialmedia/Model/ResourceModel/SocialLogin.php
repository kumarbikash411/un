<?php

namespace Unilever\socialmedia\Model\ResourceModel;

class SocialLogin extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    public function _construct()
    {
        $this->_init('bss_sociallogin', 'id');
    }
}
