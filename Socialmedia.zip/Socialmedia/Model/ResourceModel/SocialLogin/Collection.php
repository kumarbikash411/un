<?php

namespace Unilever\socialmedia\Model\ResourceModel\SocialLogin;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('Unilever\socialmedia\Model\SocialLogin', 'Unilever\socialmedia\Model\ResourceModel\SocialLogin');
    }

    protected function _initSelect()
    {
        parent::_initSelect();
        $this->getSelect()->joinLeft(
                ['ct' => $this->getTable('customer_entity')],
                'main_table.customer_id = ct.entity_id',
                '*'
            );
        return $this;
    }
}
