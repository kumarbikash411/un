<?php

namespace Unilever\Socialmedia\Model\Config\Source;

class Theme implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            'light' => __('Light'),
            'dark'  => __('Dark')
        ];
    }

}
