<?php

namespace Unilever\Socialmedia\Model\Config\Source;

class SocialType implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            ['value' => 'facebook', 'label' =>__('Facebook')],
            ['value' => 'googleplus', 'label' =>__('Googleplus')],
            
        ];
    }

}
