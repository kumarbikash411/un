<?php

namespace Unilever\Socialmedia\Model\Config\Source;

class Type implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            'image' => __('Image'),
            'audio' => __('Audio')
        ];
    }

}
