<?php

namespace Unilever\Socialmedia\Model\Config\Source;

class Display implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            ['value' => 'login', 'label' =>__('Tab Login')],
            ['value' => 'register', 'label' =>__('Tab Register')],
            ['value' => 'both', 'label' =>__('Both (Tab login and Tab register)')],
        ];
    }

}
