var config = {
    paths: {
    	'sociallogin-photo': 'Unilever_socialmedia/js/photo',
        'sociallogin': 'Unilever_socialmedia/js/social-popup'
    },
    shim: {
        'sociallogin': {
            deps: ['jquery']
        },
        'sociallogin-photo': {
            deps: ['jquery']
        }
    }
};