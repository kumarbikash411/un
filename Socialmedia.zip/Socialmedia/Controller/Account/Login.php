<?php

namespace Unilever\Socialmedia\Controller\Account;

use Magento\Framework\Controller\ResultFactory;

class Login extends \Magento\Framework\App\Action\Action
{
    protected function _getSession()
    {
        return \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Customer\Model\Session');
    }

    protected function _getUrl($url, $params = [])
    {
        return $this->_url->getUrl($url, $params);
    }

    protected function _getHelper()
    {
        return \Magento\Framework\App\ObjectManager::getInstance()->get('Unilever\s\Helper\Data');
    }

    public function execute()
    {
        $session = $this->_getSession();

        $type = $this->getRequest()->getParam('type');

        $close = '<script type="text/javascript">window.close();</script>';

        $className = 'Unilever\Socialmedia\Model\\'. ucfirst($type);

        $this->_close($session,$type,$className,$close);

        $model = \Magento\Framework\App\ObjectManager::getInstance()->get($className);

        $this->_refreshtwitter($type,$model);

        $responseTypes = $model->getResponseType();

        $this->_responseType($responseTypes,$model,$close);

        if($customerId = $model->getCustomerIdByTokenId()) {

            $redirectUrl = $this->_getHelper()->getRedirectUrl();

        }elseif($customerId = $model->getCustomerIdByEmail()) {

            $model->setCustomerIdByUserId($customerId);

            $url = $this->_getUrl('customer/account/forgotpassword');
            $message = __('Customer with email (%1) already exists in the database. If you are sure that it is your email address, please <a href="%2">click here</a> to retrieve your password and access your account.', $model->getAccountData('email'), $url);
            $this->messageManager->addNotice($message);

            $redirectUrl = $this->_getHelper()->getRedirectUrl();

        }else{

            if($customerId = $model->registerAccount()) {

                $fakemail = strpos($model->getAccountData('email'), $type.'-user.com');

                if( $fakemail ) {
                    $this->messageManager->addNotice(__('Your account needs to be updated. The email address in your profile is invalid. We were unable to send you your store accout credentials. To be able to login using store account credentials you will need to update your email address and password using our <a href="%1">Edit Account Information</a>.', \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Store\Model\Store')->getUrl('customer/account/edit'))
                        );
                    $this->messageManager->addSuccess(__('Customer registration successful.'));
                }else{
                    $this->messageManager->addSuccess(__('Customer registration successful. Your password was send to the email: %1', $model->getAccountData('email')));
                }

                if($errors = $model->getErrors()) {

                    foreach ($errors as $error) {

                        $this->messageManager->addNotice($error);

                    }
                }

                $model->setCustomerIdByTokenId($customerId);

                $redirectUrl = $this->_getHelper()->getRedirectUrl('register');

            }else{

                $session->setCustomerFormData($model->getAccountData());

                $redirectUrl = $this->_getUrl('customer/account/create', ['_secure' => true]);

                if($errors = $model->getErrors()) {

                    foreach ($errors as $error) {

                        $this->messageManager->addError($error);

                    }
                }
            }
        }

        $this->_customerphoto($customerId,$model,$session);

        if ($this->getRequest()->isXmlHttpRequest()) {

            $this->getResponse()->clearHeaders()->setHeader('Content-type', 'application/json', true);
           
            $this->getResponse()->setBody(json_encode([
                'redirectUrl' => $redirectUrl
            ]));

        } else {
            $js = '
                var windowsocial = window.opener ? window.opener.document : document;
                windowsocial.getElementById("sociallogin-login-referer").value = "'.htmlspecialchars(base64_encode($redirectUrl)).'";
                windowsocial.getElementById("sociallogin-login-submit").click();
            ';

            $body = '<script type="text/javascript">if(window.opener && window.opener.location &&  !window.opener.closed) { window.close(); }; '.$js.';</script>';

            $this->getResponse()->setBody($body);
        }
    }


    protected function _close($session,$type,$className,$close)
    {
        if ($session->isLoggedIn() || !$type || !class_exists($className) ) {

            $this->getResponse()->setBody($close);

        }
    }

    protected function _refreshtwitter($type,$model)
    {
        if ($type == 'twitter' and $this->getRequest()->getParam('refresh')) {

            return $this->_redirect($model->getButtonUrl()); 
        }
    }

    protected function _responseType($responseTypes,$model,$close)
    {
        if(is_array($responseTypes)) {
            $response = [];
            foreach ($responseTypes as $responseType) {
                $response[$responseType] = $this->getRequest()->getParam($responseType);
            }
        } else {
            $response = $this->getRequest()->getParam($responseTypes);
        }

        if(!$model->loadAccountInfo($response)) {
            $this->getResponse()->setBody($close);
        }
    }

    protected function _customerphoto($customerId,$model,$session)
    {
        if($customerId) {
            if($this->_getHelper()->photoEnabled()) {
                $model->setCustomerPhoto($customerId);
            }

            if ($session->loginById($customerId)) {
                $session->regenerateId();
            }
        }
    }

}