<?php

namespace Unilever\Socialmedia\Controller\Adminhtml\Grid;

class Index extends \Magento\Backend\App\Action{
  
	protected $resultPageFactory = false;
	
	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	) {
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
	}

	public function execute()
	{
		$resultPage = $this->resultPageFactory->create();

		$resultPage->setActiveMenu('Unilever\Socialmedia::log');
		$resultPage->getConfig()->getTitle()->prepend(__('Records Social Login'));

		$resultPage->addBreadcrumb(__('SocialLogin'), __('Records Social Login'));
		$resultPage->addBreadcrumb(__('SocialLogin'), __('Records Social Login'));

		return $resultPage;
	}

	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed('Unilever_Socialmedia::log');
	}
}

