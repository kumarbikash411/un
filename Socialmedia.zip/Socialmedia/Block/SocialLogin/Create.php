<?php


namespace unilever\Socialmedia\Block\SocialLogin;

use Magento\Customer\Block\Form\Register;

class Create extends Register
{

}
