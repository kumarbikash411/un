<?php

namespace Unilever\Socialmedia\Block\SocialLogin;

use Magento\Customer\Block\Form\Login;

class Authentication extends Login
{

}
