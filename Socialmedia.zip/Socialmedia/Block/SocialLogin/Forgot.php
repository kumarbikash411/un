<?php

namespace Unilever\Socialmedia\Block\SocialLogin;

class Forgot extends \Magento\Framework\View\Element\Template
{

}
