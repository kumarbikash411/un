<?php

namespace Unilever\Socialmedia\Block\Adminhtml\System\Config\Form;

use Magento\Store\Model\ScopeInterface;

class Baseurl extends \Magento\Config\Block\System\Config\Form\Field
{

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {

        return '<input id="'. $element->getHtmlId() .'" type="text" name="" value="'. $this->_storeManager->getStore()->getBaseUrl() .'" class="input-text sociallogin-callbackurl-autofocus" style="background-color: #EEE; color: #999;" readonly="readonly" />';
    }

}
