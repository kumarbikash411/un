<?php

namespace Unilever\Socialmedia\Block\Adminhtml\System\Config\Form;

class Sortsocial extends \Magento\Config\Block\System\Config\Form\Field
{
    protected $helper;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Unilever\Socialmedia\Helper\Data $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    public function _construct()
    {
        parent::_construct();
        $this->setTemplate('system/config/sortsocial.phtml');
    }

    public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $this->element = $element;
        
        return $this->toHtml();
    }

    public function getButtons()
    {
        return $this->helper->getButtons();
    }

    public function getPreparedButtons()
    {
        return $this->helper->getPreparedButtons();
    }

}