<?php

namespace Unilever\Socialmedia\Block\Adminhtml\System\Config\Form;

use Magento\Store\Model\ScopeInterface;

class Callbackurl extends \Magento\Config\Block\System\Config\Form\Field
{
    protected $helper;

    public function __construct(
        \Unilever\Socialmedia\Helper\Data $helper,
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    protected function _getElementHtml(\Magento\Framework\Data\Form\Element\AbstractElement $element)
    {
        $providerName = str_replace(['sociallogin_', '_callbackurl', 'bss_'], '', $element->getHtmlId());
        $url = $this->helper->getCallbackURL($providerName, true);
        
        return '<input id="'. $element->getHtmlId() .'" type="text" name="" value="'. $url .'" class="input-text sociallogin-callbackurl-autofocus" style="background-color: #EEE; color: #999;" readonly="readonly" />';
    }

}