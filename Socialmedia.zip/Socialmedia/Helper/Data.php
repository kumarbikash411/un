<?php

namespace Unilever\Socialmedia\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const XML_PATH_SECURE_IN_FRONTEND = 'web/secure/use_in_frontend';

    protected $helperbackend;

    protected $customer;

    protected $customerSession;

    protected $storeManager;

    protected $httpcontext;

    protected $filesystem;

    protected $urlInterface;

    protected $customerurl;

    protected $buttons = null;

    /**
     * Data constructor.
     * @param \Magento\Backend\Helper\Data $helperbackend
     * @param \Magento\Customer\Model\Customer $customer
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\App\Http\Context $httpcontext
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Customer\Model\Url $customerurl
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Backend\Helper\Data $helperbackend,
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Http\Context $httpcontext,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Customer\Model\Url $customerurl,
        \Magento\Framework\App\Helper\Context $context
    ) {
        $this->helperbackend = $helperbackend;
        $this->customer = $customer;
        $this->customerSession = $customerSession;
        $this->storeManager = $storeManager;
        $this->httpcontext = $httpcontext;
        $this->filesystem = $filesystem;
        $this->urlInterface = $context->getUrlBuilder();
        $this->customerurl = $customerurl;
        parent::__construct($context);
    }

    public function getConfig($path, $store = null, $scope = null)
    {
        if ($scope === null) {
            $scope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        }
        return $this->scopeConfig->getValue($path, $scope, $store);
    }
    public function getConfigSectionId()
    {
        return 'unilever_socialmedia';
    }

    public function moduleEnabled()
    {
        return (bool)$this->getConfig('unilever_socialmedia/general/enable');
    }
    public function popupEnabled()
    {
        return (bool)$this->getConfig('unilever_socialmedia/general/popup_ajax');
    }
    public function isSecure()
    {
        return (bool)$this->getConfig(self::XML_PATH_SECURE_IN_FRONTEND);
    }

    public function displayPopup(){
        return $this->getConfig('unilever_socialmedia/button_social/display_at_popup');
    }

    public function displayButtonLogin(){
       return explode(',',$this->getConfig('unilever_socialmedia/button_social/login_byclass'));
    }

    public function displayButtonRegister(){
       return explode(',',$this->getConfig('unilever_socialmedia/button_social/register_byclass'));
    }

    public function showLimit()
    {
        return $this->getConfig('unilever_socialmedia/button_social/show_limit');
    }

    public function showPassword(){
        
        return $this->moduleEnabled() && $this->getConfig('unilever_socialmedia/general/send_password');
    }

    public function photoEnabled()
    {
        return $this->moduleEnabled() && $this->getConfig('unilever_socialmedia/general/enable_photo');
    }

    public function recaptcha($path)
    {
        $recaptcha = explode(',', $this->getConfig('unilever_socialmedia/recaptcha/form_apply'));
        return in_array($path,$recaptcha);
    }

    public function getSiteKey()
    {
        return  $this->getConfig('unilever_socialmedia/recaptcha/site_key');
    }
    
    public function getSecretKey()
    {
        return  $this->getConfig('unilever_socialmedia/recaptcha/secret_key');
    }

    public function getTheme()
    {
        return $this->getConfig('unilever_socialmedia/recaptcha/theme');
    }

    public function getType()
    {
        return $this->getConfig('unilever_socialmedia/recaptcha/type');
    }

    public function getSize()
    {
        return $this->getConfig('unilever_socialmedia/recaptcha/size');
    }

    public function checkLogin()
    {
        if( $this->httpcontext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH) ){
            return false;
        }
        
        if( $this->customerSession->isLoggedIn()) {
            return false;
        }

        return true;
    }

    public function getPhotoPath($checkIsEnabled = true)
    {
        if($checkIsEnabled && !$this->photoEnabled()) {
            return false;
        }

        if(!$this->customerSession->isLoggedIn()) {
            return false;
        }
        if(!$customerId =$this->customerSession->getCustomerId()) {
            return false;
        }
        $directoryRead = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $path = 'unilever_socialmedia'. DIRECTORY_SEPARATOR .'photo'. DIRECTORY_SEPARATOR . $customerId .'.png';
        $pathUrl = $this->storeManager->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) .'unilever_socialmedia/photo/' . $customerId .'.png';

        if(!$directoryRead->isExist($path)) {
            return false;
        }

        return $pathUrl;
    }

    public function isGlobalScope()
    {
        return $this->customer->getSharingConfig()->isGlobalScope();
    }

    public function getCallbackURL($provider, $byRequest = false)
    {
        $request = $this->_getRequest();
        $websiteCode = $request->getParam('website');
        $defaultStoreId = $this->storeManager
            ->getWebsite( $byRequest? $websiteCode : null )
            ->getDefaultGroup()
            ->getDefaultStoreId();

        if(!$defaultStoreId) {
            $websites = $this->storeManager->getWebsites(true);
            foreach($websites as $website) {
                $defaultStoreId = $website
                    ->getDefaultGroup()
                    ->getDefaultStoreId();

                if ($defaultStoreId) {
                    break;
                }
            }
        }

        if(!$defaultStoreId) {
            $defaultStoreId = 1;
        }

        $url = $this->storeManager->getStore($defaultStoreId)->getUrl('socialmedia/account/login', ['type' => $provider, 'key' => null, '_nosid' => true]);

        $url = str_replace($this->helperbackend->getAreaFrontName() . '/','',$url);

        if(false !== ($length = stripos($url, '?'))) {
            $url = substr($url, 0, $length);
        }

        if($byRequest) {

            if($this->getConfig('web/seo/use_rewrites')) {
                $url = str_replace('index.php/', '', $url);
            }
        }

        return $url;
    }

    public function getTypes($onlyEnabled = true)
    {
        $groups = $this->getConfig('bss_socialmedia');
        unset($groups['general']);
        unset($groups['recaptcha']);
        unset($groups['button_social']);
        $types = [];
        if (!empty($groups)) {
            foreach ($groups as $name => $fields) {
                if($onlyEnabled && empty($fields['enable'])) {
                    continue;
                }
                $types[] = $name;
            }
        }
        return $types;
    }

    public function getButtons()
    {
        if (null === $this->buttons) {
            $types = $this->getTypes(false);

            $this->buttons = [];
            foreach ($types as $type) {
                $type = \Magento\Framework\App\ObjectManager::getInstance()->get('Unilever\Socialmedia\Model\\'. ucfirst($type));

                if($type->enabled()) {
                    $button = $type->getButton();
                    $this->buttons[$button['type']] = $button;
                }
            }
        }
        return $this->buttons;
    }

    public function getPreparedButtons()
    {
            $buttonsPrepared = [];
            $buttons = $this->getButtons();

            $storeName = $this->_getRequest()->getParam('store');
            $sortableString = $this->getConfig('unilever_socialmedia/button_social/sort_unilever_socialmedia', $storeName);
            $sortable = null;
            parse_str($sortableString, $sortable);

            if(is_array($sortable)) {
                if (isset($sortable['sort'])) {
                    foreach ($sortable['sort'] as  $button) {
                        if(isset($buttons[$button])) {
                            $buttonsPrepared[$button] = $buttons[$button];
                            unset($buttons[$button]);
                        }
                    }
                }

            }
        return array_merge($buttonsPrepared,$buttons);
    }

    public function getRedirectUrl($path = 'login')
    {
        $redirectUrl = $this->getConfig('unilever_socialmedia/general/redirect_for_'.$path);
        if ($redirectUrl == 'custom') {
            $redirectUrl = $this->getConfig('unilever_socialmedia/general/redirect_for_'.$path.'_link');
        }

        if ($redirectUrl == 'url_dashboard') {
            $redirectUrl = $this->customerurl->getDashboardUrl();
        }
        if ($redirectUrl == 'url_shoppingcart') {
            $redirectUrl = $this->urlInterface->getUrl('checkout/cart');
        }
        if ($redirectUrl == 'url_checkoutpage') {
            $redirectUrl = $this->urlInterface->getUrl('checkout');
        }
        return $redirectUrl;
    }
}
